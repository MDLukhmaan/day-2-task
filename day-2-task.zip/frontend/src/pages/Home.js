import React from "react";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/signin");
  };

  if (!user) return <p>No user logged in</p>;

  return (
    <div>
      <h2>Home</h2>
      <p>Name: {user.name}</p>
      <p>Phone: {user.phone}</p>
      <button onClick={handleLogout}>Sign Out</button>
    </div>
  );
}
